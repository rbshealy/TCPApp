# -*- coding: utf-8 -*-
"""pytelicam is a library of Python bindings for TeliCamSDK."""

from .pytelicam import *
from .pytelicam_info import *

__version__ = pytelicam_info.__version__

